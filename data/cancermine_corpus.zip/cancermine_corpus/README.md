CancerMine Corpus
-----------------

This annotation set was generated for the CancerMine project at the BC Cancer Agency. It forms part of the Personalised OncoGenomics (POG) project.

It may be freely used (and has a CC-BY 4.0 licence). Please cite the data set when used. A publication is in preparation, so please cite that when it is published.

For more information, please contact Jake Lever (jlever@bcgsc.ca)

